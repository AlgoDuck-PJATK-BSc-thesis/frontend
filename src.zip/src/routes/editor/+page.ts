import type { PageLoad } from "./$types";
import { activeProfile } from "./ComponentRegistry.svelte";

export const load: PageLoad = async ({ params, fetch }) => {
  activeProfile.profile = 'defualt';
    return {
        hideHeader: true,
        data: {
            "problemId": "",
            "title": "",
            "description": "",
            "category": {
                "name": ""
            },
            "difficulty": {
                "name": ""
            },
            "type": {
                "name": ""
            },
            "templateContents": "",
            "testCases": [],
            "tags": [],
        }
    }
}