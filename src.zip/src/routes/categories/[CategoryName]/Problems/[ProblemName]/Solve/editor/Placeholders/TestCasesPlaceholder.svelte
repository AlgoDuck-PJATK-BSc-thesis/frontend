<script lang="ts">
	import type { TestCaseComponentArgs } from "$lib/types/ComponentLoadArgs";

  let { options = $bindable() }: { options: TestCaseComponentArgs } = $props();

</script>

<main class="w-full h-full bg-gray-600"></main>

