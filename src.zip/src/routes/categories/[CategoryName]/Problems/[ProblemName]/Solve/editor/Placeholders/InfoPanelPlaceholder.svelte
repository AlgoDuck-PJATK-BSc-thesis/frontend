<script lang="ts">
	import type { InfoPanelComponentArgs } from "$lib/types/ComponentLoadArgs";

  let { options = $bindable() }: { options: InfoPanelComponentArgs } = $props();

</script>

<main class="w-full h-full bg-gray-600"></main>

