<script lang="ts">
	import type { TerminalComponentArgs } from "$lib/types/ComponentLoadArgs";

  let { options = $bindable() }: { options: TerminalComponentArgs } = $props();

</script>

<main class="w-full h-full bg-gray-600"></main>

