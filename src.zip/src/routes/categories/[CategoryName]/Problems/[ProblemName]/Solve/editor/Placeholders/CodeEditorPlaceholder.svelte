<script lang="ts">
	import type { CodeEditorArg } from "$lib/types/ComponentLoadArgs";

  let { options = $bindable() }: { options: CodeEditorArg } = $props();

</script>

<main class="w-full h-full bg-gray-600"></main>

