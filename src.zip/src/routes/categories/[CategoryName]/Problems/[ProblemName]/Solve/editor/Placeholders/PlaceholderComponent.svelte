<script lang="ts">
  let {}: { } = $props();
</script>

<main class="w-full h-full bg-gray-500">

</main>