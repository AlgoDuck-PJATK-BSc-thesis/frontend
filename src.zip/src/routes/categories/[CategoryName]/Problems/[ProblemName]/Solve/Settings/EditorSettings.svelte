<script lang="ts">
	import { userEditorFontSizePreferences, userEditorThemePreferences } from '$lib/stores/theme';
	import { applyThemeEditor, editorThemes, type EditorThemeName } from '$lib/Themes';
	import type { ComponentConfig } from '$lib/types/ComponentConfig';
	import type { DropDownMenuOptions } from '$lib/types/DropDownSelectOptions';
	import type { EditorCompArgs } from '$lib/types/EditorTabCompArgs';
	import DropDownSelect from '../IdeComponents/HelperComponents/DropDownSelect.svelte';
	import SettingsTile from './SettingsTile.svelte';

	let { options }: { options: EditorCompArgs } = $props();

	let fontSize: number = $state(16);
	let editorTheme: EditorThemeName = $state('vs-dark'); 

	userEditorThemePreferences.subscribe((pref) => {
		editorTheme = pref.editorTheme;
	});

	userEditorFontSizePreferences.subscribe((pref) => {
		fontSize = pref.fontSize;
	});

const fontSizeSelectOptions: ComponentConfig<DropDownMenuOptions> = {
		component: DropDownSelect,
			// svelte-ignore state_referenced_locally
			// intentional init only state capture as DropDownMenu handles it's own label changes after initial render
		options: {
			label: `${fontSize}px`,
			options: ['10px', '12px', '16px', '20px'],
			onSelectCallback: (selected: string) => {
				userEditorFontSizePreferences.set({fontSize: parseInt(selected.replaceAll('px', ''))})
			},
			groupId: "huh"
		}
	};

	const themeSelectOptions: ComponentConfig<DropDownMenuOptions> = {
		component: DropDownSelect,
			// svelte-ignore state_referenced_locally
			// intentional init only state capture as DropDownMenu handles it's own label changes after initial render
		options: {
			label: editorTheme,
			options: Object.keys(editorThemes),
			onSelectCallback: (selected: string) => {
				userEditorThemePreferences.set({editorTheme: selected as EditorThemeName});
				applyThemeEditor(selected as EditorThemeName)
			},
			groupId: "huh"

		}
	};
</script>

<main class="w-full h-full flex flex-col justify-start items-center px-5">
	<div class="w-full h-[12%]">
		<SettingsTile label={'Font-size'} component={fontSizeSelectOptions}/>
	</div>
	<div class="w-full h-[12%]">
		<SettingsTile label={'Theme'} component={themeSelectOptions}/>
	</div>
</main>
