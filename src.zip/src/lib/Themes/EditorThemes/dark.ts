export const dark = {
    '--color-ide-bg': '24 24 24',           
    '--color-ide-bg-hovered': '35 35 35',   
    '--color-ide-card': '30 30 30',         
    '--color-ide-accent': '255 19 240',     
    '--color-ide-dcard': '38 38 38',        
    '--color-text-primary': '146 144 195',  
    '--color-text-secondary': '210 209 252' 
}