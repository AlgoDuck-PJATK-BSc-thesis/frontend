export const dracula = {
  '--color-ide-bg': '30 31 41',        
  '--color-ide-bg-hovered': '52 55 70', 
  '--color-ide-card': '40 42 54',       
  '--color-ide-accent': '189 147 249',   
  '--color-ide-dcard': '68 71 90',         
  '--color-text-primary': '248 248 242',  
  '--color-text-secondary': '255 121 198'  
}
