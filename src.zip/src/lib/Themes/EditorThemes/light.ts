export const light = {
  '--color-ide-bg': '249 249 249',    
  '--color-ide-bg-hovered': '240 240 240', 
  '--color-ide-card': '255 255 254',    
  '--color-ide-accent': '58 134 255',    
  '--color-ide-dcard': '230 230 230',    
  '--color-text-primary': '43 44 52',  
  '--color-text-secondary': '98 70 234' 
}
