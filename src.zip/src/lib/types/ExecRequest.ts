export type ExecRequest = {
    CodeB64: string;
    Lang: string;
    ExerciseId: string;
}