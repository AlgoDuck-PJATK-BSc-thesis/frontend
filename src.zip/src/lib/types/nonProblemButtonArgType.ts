export interface NonProblemButtonArgType{
    action: string,
    command: string,
    description: string,
    onClick: () => void,
}