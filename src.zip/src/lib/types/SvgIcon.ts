
export interface svgArg{
    color: string;
    class?: string
}