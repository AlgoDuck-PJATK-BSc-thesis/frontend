export interface CodeEditorArg{
    editorContents: string,
    fontSize?: number
}