
export interface ProblemShowcase{
    id: string,
    name: string,
    synopsis: string,
}