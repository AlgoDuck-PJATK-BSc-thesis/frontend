export interface CategoryDto {
  name: string, 
  id: string,
  description: string,
}