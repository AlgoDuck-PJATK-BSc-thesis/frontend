import type { CategoryDto } from "./CategoryDto";

export interface CategoriesPageLoad {
  LoadedCategories: Array<CategoryDto>,
}