export interface ProblemDescription {
    id: string;
    description: string;
    tags: string[];
    ownedStars: number;
}