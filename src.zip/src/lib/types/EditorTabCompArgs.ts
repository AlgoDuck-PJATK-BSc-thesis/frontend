export interface SettingsTabCompArgs {}

export interface EditorCompArgs extends SettingsTabCompArgs {
	// setFontCallback: (newFontSize: number) => void,
	// setThemeCallback: (newTheme: string) => void,
	// getCurrFontSize: () => number,
	// getCurrTheme: () => string,
}