<script lang="ts">
	import type { svgArg } from "$lib/types/SvgIcon";

	let { options }: { options: svgArg } = $props();
</script>

<svg class="{options.class ?? 'w-6 h-6'}" viewBox="0 0 24 24" role="img" xmlns="http://www.w3.org/2000/svg" aria-labelledby="placeholderIconTitle" stroke="{options.color}" stroke-width="1" stroke-linecap="square" stroke-linejoin="miter" fill="none" color="#000000"> <title id="placeholderIconTitle">Placeholder</title> <rect width="18" height="18" x="3" y="3"/> <path stroke-linecap="round" d="M21 21L3 3 21 21zM21 3L3 21 21 3z"/> </svg>
